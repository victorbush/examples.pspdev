#ifndef LOADINGSCREEN_H_
#define LOADINGSCREEN_H_

#include <pspkerneltypes.h>

class LoadingScreen {

protected:
	static int RunLoadingScreen(SceSize args, void *argp);
	SceUID thid_;

public:
	LoadingScreen();
	void KillLoadingScreen();

};

#endif
